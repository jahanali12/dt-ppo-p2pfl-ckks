"""Smoke tests: exercise every component on a tiny synthetic population so
CI catches import/wiring breakage, not a reproduction of the paper's numbers.
"""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import numpy as np
import pytest

from dtppofl import aggregation, encryption, network_sim, trust
from dtppofl.baselines import BASELINES, Selection
from dtppofl.config import ExperimentConfig
from dtppofl.digital_twin import DigitalTwin, STATE_FIELDS, zscore_normalize
from dtppofl.fl_experiment import ClientData, FLExperiment
from dtppofl.forecaster import GRUForecaster, count_params, make_windows, fit_normalization
from dtppofl.reward import RoundQuantities, compute_reward


def test_gru_param_count_matches_paper():
    cfg = ExperimentConfig().forecaster
    model = GRUForecaster(cfg)
    assert count_params(model) == 1969  # Sec. 6.4: "1969 trainable parameters"


def test_network_sim_ranges():
    cfg = ExperimentConfig().network
    rng = np.random.default_rng(0)
    net = network_sim.sample_client_network_state(rng, cfg)
    assert cfg.uplink_mbps_range[0] <= net.uplink_mbps <= cfg.uplink_mbps_range[1]
    assert cfg.one_way_latency_ms_range[0] <= net.latency_ms <= cfg.one_way_latency_ms_range[1] * 5


def test_trust_ema_formula():
    cfg = ExperimentConfig().trust
    rho = trust.update_trust(prev_trust=0.5, client_loss=1.0, round_median_loss=1.0, cfg=cfg)
    assert rho == pytest.approx(0.8 * 0.5 + 0.2 * 1.0)


def test_reward_matches_eq4():
    cfg = ExperimentConfig().reward
    q = RoundQuantities(
        mse=0.5, mean_latency_ms=100, mean_energy_joules=5, mean_comm_bytes=1_000_000,
        he_overhead_ms=50, mean_trust=0.8,
    )
    r = compute_reward(q, cfg)
    expected = (
        1.0 * (1 / 1.5) - 0.15 * (100 / 100) - 0.10 * (5 / 10) - 0.10 * (1_000_000 / 1e6)
        - 0.05 * (50 / 100) + 0.20 * 0.8
    )
    assert r == pytest.approx(expected)


def test_ckks_round_trip():
    cfg = ExperimentConfig().ckks
    ctx = encryption.make_context(cfg)
    v1 = np.array([1.0, 2.0, 3.0])
    v2 = np.array([4.0, 5.0, 6.0])
    r1 = encryption.encrypt_vector(ctx, v1, cfg)
    r2 = encryption.encrypt_vector(ctx, v2, cfg)
    agg = encryption.sum_and_decrypt([r1.ciphertext, r2.ciphertext], ctx, divide_by=2)
    np.testing.assert_allclose(agg.plaintext_vector, (v1 + v2) / 2, atol=1e-2)


def test_digital_twin_roundtrip():
    with tempfile.TemporaryDirectory() as tmp:
        dt = DigitalTwin(os.path.join(tmp, "dt.sqlite"))
        from dtppofl.digital_twin import ClientStateRow

        row = ClientStateRow(
            experiment_id="e1", round_idx=0, client_id="c0",
            mu=1.0, sigma=0.5, js_div=0.1, uplink_mbps=100, latency_ms=5, packet_loss=0.01,
            edge_compute_gflops=200, edge_congestion=0.1, prev_loss=0.3, staleness=0, trust=0.5,
        )
        dt.write_client_state(row)
        dt.commit()
        mat = dt.feature_matrix("e1", ["c0"])
        assert mat.shape == (1, len(STATE_FIELDS))
        normed = zscore_normalize(mat)
        assert normed.shape == mat.shape
        dt.close()


def test_make_windows_and_normalization():
    series = np.arange(60, dtype=float)
    norm = fit_normalization(series[:40])
    transformed = norm.transform(series)
    X, y = make_windows(transformed, lookback=48, horizon=1)
    assert X.shape[1] == 48
    assert y.shape[1] == 1
    assert len(X) == 60 - 48 - 1 + 1


def _make_tiny_clients(n=5, n_windows=20, lookback=8, horizon=1):
    clients = {}
    rng = np.random.default_rng(0)
    for i in range(n):
        X = rng.normal(size=(n_windows, lookback))
        y = rng.normal(size=(n_windows, horizon))
        clients[f"c{i}"] = ClientData(
            client_id=f"c{i}", train_X=X, train_y=y, val_X=X, val_y=y, test_X=X, test_y=y,
            mu=float(rng.normal()), sigma=float(abs(rng.normal())), js_div=float(abs(rng.normal()) * 0.1),
        )
    return clients


@pytest.mark.parametrize("name", ["B1_local_only", "B3_p2pfl", "B4_p2pfl_he"])
def test_fl_experiment_runs(name):
    cfg = ExperimentConfig()
    cfg.forecaster.lookback = 8
    cfg.digital_twin.db_path = tempfile.mktemp(suffix=".sqlite")
    clients = _make_tiny_clients(n=4, lookback=8)
    bcfg = BASELINES[name]
    exp = FLExperiment(f"smoke_{name}", clients, bcfg, cfg, seed=0)
    results = exp.run(2)
    assert len(results) == 2
    metrics = exp.test_metrics()
    assert "test_mse" in metrics
    exp.close()
