#!/usr/bin/env python
"""Main seven-baseline comparison (B0-B6), 3 seeds -> 21 runs (Sec. 6.6-6.7,
Table 6)."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from common import build_clients
from dtppofl.baselines import BASELINES
from dtppofl.config import load_config
from dtppofl.fl_experiment import FLExperiment
from dtppofl.metrics import RunRecord, append_run

try:
    from stable_baselines3 import PPO
except Exception:
    PPO = None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--ppo-policy", default="results/ppo_policy.zip")
    args = ap.parse_args()

    cfg = load_config(args.config)
    clients = build_clients(args.data_dir, cfg)

    ppo_model = None
    if PPO is not None and Path(args.ppo_policy).exists():
        ppo_model = PPO.load(args.ppo_policy)
    else:
        print("[warn] no trained PPO policy found; B6 will fall back to random selection. "
              "Run scripts/train_orchestrator.py first for a faithful B6 run.")

    for name, bcfg in BASELINES.items():
        for seed in cfg.fl.main_comparison_seeds:
            exp_id = f"main_{name}_seed{seed}"
            print(f"[run] {exp_id}")
            exp = FLExperiment(
                exp_id, clients, bcfg, cfg, seed=seed,
                orchestrator_model=(ppo_model if bcfg.selection.value == "ppo_policy" else None),
            )
            round_results = exp.run(cfg.fl.n_rounds)
            test = exp.test_metrics()
            last = round_results[-1]
            append_run(
                RunRecord(
                    experiment_id=exp_id, batch="main", config_name=name, seed=seed,
                    n_clients=len(clients), n_rounds=cfg.fl.n_rounds,
                    test_mse=test["test_mse"], test_mae=test["test_mae"], test_rmse=test["test_rmse"],
                    mean_latency_ms=last.mean_latency_ms, mean_energy_joules=last.mean_energy_joules,
                    mean_comm_bytes=last.comm_bytes, he_overhead_ms=last.he_overhead_ms,
                    wall_clock_s=sum(r.wall_clock_ms for r in round_results) / 1000.0,
                ),
                cfg.results_csv,
            )
            exp.close()


if __name__ == "__main__":
    main()
