"""Shared helpers for the run_*.py scripts: build a ClientData dict from a
raw-partition directory, used by every experiment-matrix script."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from typing import Dict

import numpy as np

from dtppofl.config import ExperimentConfig
from dtppofl.data import build_client_dataset, chronological_split
from dtppofl.fl_experiment import ClientData
from dtppofl.forecaster import fit_normalization, make_windows


def build_clients(
    data_dir: str, cfg: ExperimentConfig, window_start: str = "2012-01-01", window_end: str = "2014-01-31",
    max_clients: int | None = None,
) -> Dict[str, ClientData]:
    per_household, stats, het = build_client_dataset(
        data_dir, window_start, window_end, coverage_threshold=cfg.fl.coverage_threshold
    )
    print(
        f"[data] {stats.raw_files_used} files, {stats.raw_rows} raw rows, "
        f"{stats.households_meeting_coverage}/{stats.households_candidate} households kept "
        f"({stats.final_std} std / {stats.final_tou} ToU), {stats.final_rows} clean rows"
    )

    client_ids = list(per_household.keys())
    if max_clients is not None:
        client_ids = client_ids[:max_clients]

    lookback = cfg.forecaster.lookback
    horizon = cfg.forecaster.horizon
    clients: Dict[str, ClientData] = {}
    for cid in client_ids:
        g = per_household[cid]
        splits = chronological_split(g)
        mu = float(g["consumption_kwh"].mean())
        sigma = float(g["consumption_kwh"].std())
        js = float(het["js_divergence_per_household"].get(cid, 0.0))

        norm = fit_normalization(splits["train"]["consumption_kwh"].to_numpy())

        def _windows(split_df):
            series = norm.transform(split_df["consumption_kwh"].to_numpy())
            return make_windows(series, lookback, horizon)

        train_X, train_y = _windows(splits["train"])
        val_X, val_y = _windows(splits["val"])
        test_X, test_y = _windows(splits["test"])

        if len(train_X) == 0:
            continue  # not enough history for even one window; skip this client

        clients[cid] = ClientData(
            client_id=cid, train_X=train_X, train_y=train_y, val_X=val_X, val_y=val_y,
            test_X=test_X, test_y=test_y, mu=mu, sigma=sigma, js_div=js,
        )
    return clients
