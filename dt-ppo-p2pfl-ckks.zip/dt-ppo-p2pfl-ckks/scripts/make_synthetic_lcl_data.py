#!/usr/bin/env python
"""Generate a small synthetic dataset with the same schema as the Low Carbon
London partition files (household_id, tariff, timestamp, consumption_kwh),
so the pipeline can be run end-to-end without the real (gated-access)
dataset. NOT a substitute for the real data -- see the top-level README.
"""
from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd


def make_household_series(
    rng: np.random.Generator, n_days: int, base_load: float, seasonality: float, noise: float
) -> pd.DataFrame:
    slots_per_day = 48
    n_slots = n_days * slots_per_day
    t = np.arange(n_slots)
    daily_cycle = 0.3 * np.sin(2 * np.pi * (t % slots_per_day) / slots_per_day - np.pi / 2) + 0.3
    yearly_cycle = seasonality * np.sin(2 * np.pi * t / (365 * slots_per_day))
    series = base_load + daily_cycle + yearly_cycle + rng.normal(0, noise, size=n_slots)
    series = np.clip(series, 0.0, None)
    start = pd.Timestamp("2012-01-01")
    timestamps = start + pd.to_timedelta(t * 30, unit="m")
    return pd.DataFrame({"timestamp": timestamps, "consumption_kwh": series})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default="data/synthetic")
    ap.add_argument("--n-households", type=int, default=40)
    ap.add_argument("--n-days", type=int, default=400)
    ap.add_argument("--n-files", type=int, default=4)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    os.makedirs(args.out_dir, exist_ok=True)

    rows = []
    for i in range(args.n_households):
        hid = f"SYN{i:04d}"
        tariff = "Std" if rng.uniform() < 0.78 else "ToU"  # ~ matches the paper's 119/32 split ratio
        base_load = rng.uniform(0.15, 0.6)
        seasonality = rng.uniform(0.05, 0.3)
        noise = rng.uniform(0.03, 0.15)
        df = make_household_series(rng, args.n_days, base_load, seasonality, noise)
        df["household_id"] = hid
        df["tariff"] = tariff
        rows.append(df[["household_id", "tariff", "timestamp", "consumption_kwh"]])

    full = pd.concat(rows, ignore_index=True)
    # Inject a few duplicate and missing rows so the cleaning step in data.py
    # has something real to remove, matching the paper's reported pipeline.
    dup_sample = full.sample(frac=0.002, random_state=args.seed)
    full = pd.concat([full, dup_sample], ignore_index=True)
    missing_idx = full.sample(frac=0.0005, random_state=args.seed).index
    full.loc[missing_idx, "consumption_kwh"] = np.nan

    shuffled = full.sample(frac=1.0, random_state=args.seed).reset_index(drop=True)
    chunk_indices = np.array_split(np.arange(len(shuffled)), args.n_files)
    for i, idx in enumerate(chunk_indices):
        chunk = shuffled.iloc[idx]
        chunk.to_csv(os.path.join(args.out_dir, f"synthetic_part_{i:02d}.csv"), index=False)

    print(f"Wrote {args.n_files} CSV partitions for {args.n_households} synthetic households to {args.out_dir}")


if __name__ == "__main__":
    main()
