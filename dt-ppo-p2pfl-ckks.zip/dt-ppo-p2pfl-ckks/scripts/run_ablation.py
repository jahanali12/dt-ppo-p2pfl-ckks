#!/usr/bin/env python
"""Six-way component ablation of the proposed framework, 2 seeds -> 12 runs
(Sec. 6.6, Table 8)."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from common import build_clients
from dtppofl.baselines import ablation_configs
from dtppofl.config import load_config
from dtppofl.fl_experiment import FLExperiment
from dtppofl.metrics import RunRecord, append_run

try:
    from stable_baselines3 import PPO
except Exception:
    PPO = None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--ppo-policy", default="results/ppo_policy.zip")
    args = ap.parse_args()

    cfg = load_config(args.config)
    clients = build_clients(args.data_dir, cfg)

    ppo_model = PPO.load(args.ppo_policy) if (PPO is not None and Path(args.ppo_policy).exists()) else None

    for name, bcfg in ablation_configs().items():
        for seed in cfg.fl.ablation_scalability_robustness_seeds:
            exp_id = f"ablation_{name}_seed{seed}"
            print(f"[run] {exp_id}")
            exp = FLExperiment(
                exp_id, clients, bcfg, cfg, seed=seed,
                orchestrator_model=(ppo_model if bcfg.selection.value == "ppo_policy" else None),
            )
            round_results = exp.run(cfg.fl.n_rounds)
            test = exp.test_metrics()
            last = round_results[-1]
            append_run(
                RunRecord(
                    experiment_id=exp_id, batch="ablation", config_name=name, seed=seed,
                    n_clients=len(clients), n_rounds=cfg.fl.n_rounds,
                    test_mse=test["test_mse"], test_mae=test["test_mae"], test_rmse=test["test_rmse"],
                    mean_latency_ms=last.mean_latency_ms, mean_energy_joules=last.mean_energy_joules,
                    mean_comm_bytes=last.comm_bytes, he_overhead_ms=last.he_overhead_ms,
                    wall_clock_s=sum(r.wall_clock_ms for r in round_results) / 1000.0,
                ),
                cfg.results_csv,
            )
            exp.close()


if __name__ == "__main__":
    main()
