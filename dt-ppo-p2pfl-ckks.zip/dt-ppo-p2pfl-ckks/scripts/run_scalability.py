#!/usr/bin/env python
"""Scalability sweep: proposed framework (B6) and FedAvg (B2) at 30/75/151
clients, 2 seeds -> 12 runs (Sec. 6.6, Table 7). Scale-matched PPO policies
are (re)trained per client count since the policy's input dimensionality
depends on population size (Sec. 6.6), unless results/ppo_policy_<n>.zip
already exists.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import numpy as np

from common import build_clients
from dtppofl.baselines import BASELINES
from dtppofl.config import load_config
from dtppofl.fl_experiment import FLExperiment
from dtppofl.metrics import RunRecord, append_run
from dtppofl.orchestrator import train_ppo


def get_or_train_ppo(cfg, clients_subset, n, out_dir, seed):
    path = Path(out_dir) / f"ppo_policy_{n}.zip"
    try:
        from stable_baselines3 import PPO
    except Exception:
        return None
    if path.exists():
        return PPO.load(str(path))
    mu = np.array([c.mu for c in clients_subset.values()])
    sigma = np.array([c.sigma for c in clients_subset.values()])
    js = np.array([c.js_div for c in clients_subset.values()])
    model = train_ppo(cfg, n, mu, sigma, js, seed=seed)
    model.save(str(path))
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--out-dir", default="results")
    args = ap.parse_args()

    cfg = load_config(args.config)
    all_clients = build_clients(args.data_dir, cfg)
    all_ids = list(all_clients.keys())

    for n in cfg.fl.scalability_client_counts:
        n_use = min(n, len(all_ids))
        subset_ids = all_ids[:n_use]
        subset = {cid: all_clients[cid] for cid in subset_ids}

        ppo_model = get_or_train_ppo(cfg, subset, n_use, args.out_dir, seed=0)

        for config_name in ("B2_fedavg", "B6_proposed"):
            bcfg = BASELINES[config_name]
            for seed in cfg.fl.ablation_scalability_robustness_seeds:
                exp_id = f"scalability_{config_name}_n{n_use}_seed{seed}"
                print(f"[run] {exp_id}")
                exp = FLExperiment(
                    exp_id, subset, bcfg, cfg, seed=seed,
                    orchestrator_model=(ppo_model if bcfg.selection.value == "ppo_policy" else None),
                )
                round_results = exp.run(cfg.fl.n_rounds)
                test = exp.test_metrics()
                last = round_results[-1]
                append_run(
                    RunRecord(
                        experiment_id=exp_id, batch="scalability", config_name=config_name, seed=seed,
                        n_clients=n_use, n_rounds=cfg.fl.n_rounds,
                        test_mse=test["test_mse"], test_mae=test["test_mae"], test_rmse=test["test_rmse"],
                        mean_latency_ms=last.mean_latency_ms, mean_energy_joules=last.mean_energy_joules,
                        mean_comm_bytes=last.comm_bytes, he_overhead_ms=last.he_overhead_ms,
                        wall_clock_s=sum(r.wall_clock_ms for r in round_results) / 1000.0,
                    ),
                    cfg.results_csv,
                )
                exp.close()


if __name__ == "__main__":
    main()
