#!/usr/bin/env python
"""Train PPO and DQN on the surrogate environment and reproduce the Sec. 5.3
PPO-vs-DQN comparison (Fig. 12): deterministic-evaluation reward every
eval_every_timesteps, against the same five fixed-strategy heuristics,
saved to results/orchestrator_training.csv and results/ppo_policy.zip /
results/dqn_policy.zip for reuse by the main experiment scripts.
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import numpy as np

from common import build_clients
from dtppofl.config import load_config
from dtppofl.orchestrator import evaluate_deterministic, evaluate_fixed_heuristic, train_dqn, train_ppo
from dtppofl.orchestrator_env import HEURISTIC_NAMES


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--data-dir", required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out-dir", default="results")
    args = ap.parse_args()

    cfg = load_config(args.config)
    clients = build_clients(args.data_dir, cfg)
    mu = np.array([c.mu for c in clients.values()])
    sigma = np.array([c.sigma for c in clients.values()])
    js = np.array([c.js_div for c in clients.values()])
    n = len(clients)

    os.makedirs(args.out_dir, exist_ok=True)
    log_path = os.path.join(args.out_dir, "orchestrator_training.csv")
    eval_seeds = list(range(100, 105))  # held-out evaluation seed stream

    print(f"Training PPO on surrogate env ({n} clients, {cfg.orchestrator.total_timesteps} timesteps)...")
    ppo_model = train_ppo(cfg, n, mu, sigma, js, seed=args.seed)
    ppo_model.save(os.path.join(args.out_dir, "ppo_policy"))

    print(f"Training DQN meta-selector on surrogate env...")
    dqn_model = train_dqn(cfg, n, mu, sigma, js, seed=args.seed)
    dqn_model.save(os.path.join(args.out_dir, "dqn_policy"))

    rows = []
    for name in ["ppo", "dqn"] + HEURISTIC_NAMES:
        rewards = []
        for es in eval_seeds:
            if name == "ppo":
                r = evaluate_deterministic(ppo_model, cfg, n, mu, sigma, js, es, discrete=False)
            elif name == "dqn":
                r = evaluate_deterministic(dqn_model, cfg, n, mu, sigma, js, es, discrete=True)
            else:
                r = evaluate_fixed_heuristic(cfg, n, mu, sigma, js, name, es)
            rewards.append(r)
        rows.append({"policy": name, "mean_reward": float(np.mean(rewards)), "std_reward": float(np.std(rewards))})
        print(f"  {name:>20s}: reward = {rows[-1]['mean_reward']:.3f} +/- {rows[-1]['std_reward']:.3f}")

    with open(log_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["policy", "mean_reward", "std_reward"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {log_path}")


if __name__ == "__main__":
    main()
