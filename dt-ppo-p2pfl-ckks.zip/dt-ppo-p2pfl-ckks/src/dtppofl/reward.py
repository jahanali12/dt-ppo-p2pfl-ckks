"""Multi-objective per-round reward (Sec. 3.5, Eq. 4).

R_r = w1*A_bar_r - w2*(L_bar_r/100) - w3*(E_bar_r/10) - w4*(B_bar_r/1e6)
      - w5*(H_bar_r/100) + w6*rho_bar_r

where A_bar_r = 1 / (1 + MSE_r) is a bounded accuracy proxy, L/E/B are the
round's mean latency/energy/communication volume, H is the combined CKKS
encryption+aggregation time, and rho_bar is the mean trust of selected
participants. Default weights (1.0, 0.15, 0.10, 0.10, 0.05, 0.20) and the
normalization constants are fixed, not fitted (Sec. 3.5).
"""
from __future__ import annotations

from dataclasses import dataclass

from .config import RewardConfig


@dataclass
class RoundQuantities:
    mse: float
    mean_latency_ms: float
    mean_energy_joules: float
    mean_comm_bytes: float
    he_overhead_ms: float
    mean_trust: float


def accuracy_proxy(mse: float) -> float:
    return 1.0 / (1.0 + max(mse, 0.0))


def compute_reward(q: RoundQuantities, cfg: RewardConfig) -> float:
    a_bar = accuracy_proxy(q.mse)
    return (
        cfg.w_accuracy * a_bar
        - cfg.w_latency * (q.mean_latency_ms / cfg.latency_norm)
        - cfg.w_energy * (q.mean_energy_joules / cfg.energy_norm)
        - cfg.w_comm * (q.mean_comm_bytes / cfg.comm_norm)
        - cfg.w_he_overhead * (q.he_overhead_ms / cfg.he_overhead_norm)
        + cfg.w_trust * q.mean_trust
    )
