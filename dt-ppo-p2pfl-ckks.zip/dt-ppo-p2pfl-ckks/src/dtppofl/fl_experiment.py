"""Main per-round federated learning loop: Algorithm 1 ("Proposed DT +
AI-Native-Orchestrated P2PFL + HE round"), parameterized to run any of the
seven baselines (B0-B6) or an ablation variant, matching the paper's
Algorithm 1 listing line for line.

  Require: global model theta_r, client set C, DT state store D, frozen PPO pi
  1. Sample simulated network/edge state for round r
  2. Read/update DT feature matrix X_r from D
  3. scores <- pi(normalize(X_r)); S_r <- top-k(scores)
  4. Exclude i in S_r with trust rho_{i,r} < threshold
  5. for each i in S_r (in parallel): theta_i <- LocalTrain(theta_r, data_i); c_i <- Encrypt(theta_i)
  6. c_sum <- sum_i c_i (round-robin relay); theta_{r+1} <- Decrypt(c_sum)/|S_r|
  7. Evaluate theta_{r+1} on held-out validation windows -> MSE_r
  8. Update trust rho_{i,r} from deviation of reported local loss from round median
  9. Compute reward R_r; write per-client and per-round state to D
  Return theta_{r+1}
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from . import aggregation, baselines, encryption, network_sim, trust as trust_mod
from .baselines import Aggregation, BaselineConfig, Selection
from .config import ExperimentConfig
from .digital_twin import ClientStateRow, DigitalTwin, STATE_FIELDS, zscore_normalize
from .forecaster import (
    GRUForecaster, average_params, evaluate, get_flat_params, set_flat_params,
    train_one_client,
)
from .reward import RoundQuantities, compute_reward


@dataclass
class ClientData:
    client_id: str
    train_X: np.ndarray
    train_y: np.ndarray
    val_X: np.ndarray
    val_y: np.ndarray
    test_X: np.ndarray
    test_y: np.ndarray
    mu: float
    sigma: float
    js_div: float


@dataclass
class RoundResult:
    round_idx: int
    val_mse: float
    reward: float
    n_participants: int
    mean_latency_ms: float
    mean_energy_joules: float
    comm_bytes: int
    he_overhead_ms: float
    wall_clock_ms: float


class FLExperiment:
    def __init__(
        self,
        experiment_id: str,
        clients: Dict[str, ClientData],
        config: BaselineConfig,
        exp_cfg: ExperimentConfig,
        seed: int = 0,
        orchestrator_model=None,
        orchestrator_discrete: bool = False,
    ):
        self.experiment_id = experiment_id
        self.clients = clients
        self.config = config
        self.exp_cfg = exp_cfg
        self.rng = np.random.default_rng(seed)
        self.orchestrator_model = orchestrator_model
        self.orchestrator_discrete = orchestrator_discrete

        self.client_ids = list(clients.keys())
        self.n_clients = len(self.client_ids)
        self.k = max(1, round(config.participation_fraction * self.n_clients))

        self.dt = DigitalTwin(exp_cfg.digital_twin.db_path)
        self.ckks_context = (
            encryption.make_context(exp_cfg.ckks) if config.aggregation == Aggregation.P2P_CKKS else None
        )

        self.global_model = GRUForecaster(exp_cfg.forecaster)
        # B1 (local-only) keeps one persistent model per client, never aggregated.
        self._local_models: Dict[str, GRUForecaster] = (
            {cid: GRUForecaster(exp_cfg.forecaster) for cid in self.client_ids}
            if not config.is_federated and not config.is_centralized_pool
            else {}
        )
        self.staleness = {cid: 0 for cid in self.client_ids}
        self.trust = {cid: exp_cfg.digital_twin.trust_init for cid in self.client_ids}
        self.unreliable = {
            cid: self.rng.uniform() < 0.0 for cid in self.client_ids
        }  # overwritten by set_unreliable_fraction() when robustness study is run

        self._seed_initial_dt_state()

    def _seed_initial_dt_state(self) -> None:
        """Write a round=-1 state row per client before any round runs, so the
        orchestrator's first-round feature matrix (Algorithm 1, line 2) sees
        each client's real mu/sigma/js_div immediately rather than zeros --
        those three fields are known upfront from the data, not something the
        pipeline measures round by round."""
        for cid in self.client_ids:
            cd = self.clients[cid]
            row = ClientStateRow(
                experiment_id=self.experiment_id, round_idx=-1, client_id=cid,
                mu=cd.mu, sigma=cd.sigma, js_div=cd.js_div,
                uplink_mbps=0.0, latency_ms=0.0, packet_loss=0.0,
                edge_compute_gflops=0.0, edge_congestion=0.0,
                prev_loss=0.0, staleness=0, trust=self.trust[cid],
            )
            self.dt.write_client_state(row)
        self.dt.commit()

    def set_unreliable_fraction(self, fraction: float) -> None:
        self.unreliable = {
            cid: bool(self.rng.uniform() < fraction) for cid in self.client_ids
        }

    # --- selection -------------------------------------------------------

    def _select_clients(self, round_idx: int) -> List[str]:
        cfg = self.config
        if cfg.selection == Selection.ALL:
            return list(self.client_ids)

        if cfg.selection == Selection.RANDOM:
            return baselines.select_random(self.client_ids, self.k, self.rng)

        if cfg.selection == Selection.ROUND_ROBIN:
            return baselines.select_round_robin(self.client_ids, self.k, round_idx)

        if cfg.selection == Selection.RESOURCE_AWARE:
            compute = {cid: self._edge_state[cid][0] for cid in self.client_ids}
            congestion = {cid: self._edge_state[cid][1] for cid in self.client_ids}
            return baselines.select_resource_aware(self.client_ids, self.k, compute, congestion)

        if cfg.selection == Selection.TRUST_AWARE:
            return baselines.select_trust_aware(self.client_ids, self.k, self.trust)

        if cfg.selection == Selection.HETEROGENEITY_AWARE:
            js = {cid: self.clients[cid].js_div for cid in self.client_ids}
            return baselines.select_heterogeneity_aware(self.client_ids, self.k, js)

        if cfg.selection in (Selection.PPO_POLICY, Selection.DQN_META):
            if self.orchestrator_model is None:
                # No trained policy supplied -> fall back to random, but this
                # should not happen for B6/B5-equivalent runs; callers must
                # pass a frozen model for PPO_POLICY/DQN_META selection.
                return baselines.select_random(self.client_ids, self.k, self.rng)
            raw = self.dt.feature_matrix(self.experiment_id, self.client_ids)
            normed = zscore_normalize(raw)
            if self.orchestrator_discrete:
                from .orchestrator import evaluate_fixed_heuristic  # noqa: F401 (import kept local)
                action, _ = self.orchestrator_model.predict(normed.ravel(), deterministic=True)
                from .orchestrator_env import HEURISTIC_NAMES
                name = HEURISTIC_NAMES[int(action)]
                if name == "random":
                    return baselines.select_random(self.client_ids, self.k, self.rng)
                if name == "round_robin":
                    return baselines.select_round_robin(self.client_ids, self.k, round_idx)
                if name == "resource_aware":
                    compute = {cid: self._edge_state[cid][0] for cid in self.client_ids}
                    congestion = {cid: self._edge_state[cid][1] for cid in self.client_ids}
                    return baselines.select_resource_aware(self.client_ids, self.k, compute, congestion)
                if name == "trust_aware":
                    return baselines.select_trust_aware(self.client_ids, self.k, self.trust)
                return baselines.select_heterogeneity_aware(
                    self.client_ids, self.k, {cid: self.clients[cid].js_div for cid in self.client_ids}
                )
            action, _ = self.orchestrator_model.predict(normed.ravel(), deterministic=True)
            scores = np.asarray(action).ravel()
            return baselines.select_top_k_from_scores(self.client_ids, self.k, scores)

        raise ValueError(f"Unknown selection strategy: {cfg.selection}")

    # --- one round ---------------------------------------------------------

    def run_round(self, round_idx: int) -> RoundResult:
        t0 = time.perf_counter()
        cfg = self.config
        net_cfg = self.exp_cfg.network

        # Step 1: sample simulated network/edge state for this round.
        self._net_state = {
            cid: network_sim.sample_client_network_state(self.rng, net_cfg, self.unreliable[cid])
            for cid in self.client_ids
        }
        self._edge_state = {
            cid: (
                (e := network_sim.sample_edge_state(self.rng, net_cfg)).compute_gflops,
                e.congestion,
            )
            for cid in self.client_ids
        }

        # Step 3-4: select participants (and trust-aware exclusion).
        selected = self._select_clients(round_idx)
        if cfg.use_trust_exclusion:
            mask = trust_mod.trust_exclusion_mask(
                {cid: self.trust[cid] for cid in selected}, self.exp_cfg.trust
            )
            selected = [cid for cid in selected if mask.get(cid, True)]
            if not selected:
                selected = [self.client_ids[0]]

        # Step 5: local training (+ encryption happens inside aggregation).
        local_params: Dict[str, np.ndarray] = {}
        local_losses: Dict[str, float] = {}
        global_flat = get_flat_params(self.global_model)

        if cfg.is_centralized_pool:
            selected = list(self.client_ids)
            model = GRUForecaster(self.exp_cfg.forecaster)
            set_flat_params(model, global_flat)
            Xs = np.concatenate([self.clients[c].train_X for c in selected if len(self.clients[c].train_X)])
            ys = np.concatenate([self.clients[c].train_y for c in selected if len(self.clients[c].train_y)])
            loss = train_one_client(model, Xs, ys, self.exp_cfg.forecaster)
            new_flat = get_flat_params(model)
            for c in selected:
                local_losses[c] = loss
            agg_outcome = aggregation.AggregationOutcome(new_params=new_flat, comm_bytes=0, he_overhead_ms=0.0)
        elif not cfg.is_federated:  # B1 local-only: never aggregated, one persistent model/client
            round_mses = []
            for cid in selected:
                cd = self.clients[cid]
                model = self._local_models[cid]
                loss = train_one_client(model, cd.train_X, cd.train_y, self.exp_cfg.forecaster)
                local_losses[cid] = loss
                round_mses.append(evaluate(model, cd.val_X, cd.val_y)["mse"])
            agg_outcome = aggregation.AggregationOutcome(
                new_params=global_flat, comm_bytes=0, he_overhead_ms=0.0
            )
            val_mse = float(np.nanmean(round_mses)) if round_mses else float("nan")
            return self._finalize_round(round_idx, t0, selected, local_losses, agg_outcome, val_mse_override=val_mse)
        else:
            for cid in selected:
                cd = self.clients[cid]
                model = GRUForecaster(self.exp_cfg.forecaster)
                set_flat_params(model, global_flat)
                loss = train_one_client(model, cd.train_X, cd.train_y, self.exp_cfg.forecaster)
                local_losses[cid] = loss
                local_params[cid] = get_flat_params(model)

            # Step 6: aggregate (FedAvg / plain P2P round-robin / CKKS P2P round-robin).
            if cfg.aggregation == Aggregation.FEDAVG:
                agg_outcome = aggregation.fedavg(local_params)
            elif cfg.aggregation == Aggregation.P2P_PLAIN:
                agg_outcome = aggregation.round_robin_plain(local_params)
            elif cfg.aggregation == Aggregation.P2P_CKKS:
                agg_outcome = aggregation.round_robin_ckks(
                    local_params, self.exp_cfg.ckks, context=self.ckks_context
                )
            else:
                agg_outcome = aggregation.AggregationOutcome(
                    new_params=average_params(list(local_params.values())), comm_bytes=0, he_overhead_ms=0.0
                )

        set_flat_params(self.global_model, agg_outcome.new_params)

        # Step 7: evaluate on held-out validation windows.
        val_mses = []
        for cid in selected:
            cd = self.clients[cid]
            val_mses.append(evaluate(self.global_model, cd.val_X, cd.val_y)["mse"])
        val_mse = float(np.nanmean(val_mses)) if val_mses else float("nan")

        return self._finalize_round(round_idx, t0, selected, local_losses, agg_outcome, val_mse_override=val_mse)

    def _finalize_round(
        self, round_idx, t0, selected, local_losses, agg_outcome, val_mse_override
    ) -> RoundResult:
        # Step 8: update trust from deviation of reported local loss from round median.
        if local_losses:
            self.trust.update(trust_mod.update_trust_batch(self.trust, local_losses, self.exp_cfg.trust))

        for cid in self.client_ids:
            self.staleness[cid] = 0 if cid in selected else self.staleness[cid] + 1

        mean_latency = float(np.mean([
            network_sim.transmission_time_ms(
                agg_outcome.comm_bytes // max(len(selected), 1), self._net_state[cid], self.exp_cfg.network
            ) for cid in selected
        ])) if selected and agg_outcome.comm_bytes > 0 else 0.0
        mean_energy = float(np.sum([
            network_sim.device_energy_joules(
                agg_outcome.comm_bytes // max(len(selected), 1), self.rng, self.exp_cfg.network
            ) for cid in selected
        ])) if selected and agg_outcome.comm_bytes > 0 else 0.0
        mean_trust_selected = float(np.mean([self.trust[cid] for cid in selected])) if selected else 0.0

        q = RoundQuantities(
            mse=val_mse_override,
            mean_latency_ms=mean_latency,
            mean_energy_joules=mean_energy,
            mean_comm_bytes=float(agg_outcome.comm_bytes),
            he_overhead_ms=agg_outcome.he_overhead_ms,
            mean_trust=mean_trust_selected,
        )
        reward = compute_reward(q, self.exp_cfg.reward)

        # Step 9: write per-client and per-round state to the Digital Twin.
        for cid in self.client_ids:
            cd = self.clients[cid]
            net = getattr(self, "_net_state", {}).get(cid)
            edge = getattr(self, "_edge_state", {}).get(cid, (0.0, 0.0))
            row = ClientStateRow(
                experiment_id=self.experiment_id, round_idx=round_idx, client_id=cid,
                mu=cd.mu, sigma=cd.sigma, js_div=cd.js_div,
                uplink_mbps=net.uplink_mbps if net else 0.0,
                latency_ms=net.latency_ms if net else 0.0,
                packet_loss=net.packet_loss if net else 0.0,
                edge_compute_gflops=edge[0], edge_congestion=edge[1],
                prev_loss=local_losses.get(cid, 0.0), staleness=self.staleness[cid],
                trust=self.trust[cid],
            )
            self.dt.write_client_state(row)

        wall_clock_ms = (time.perf_counter() - t0) * 1000.0
        self.dt.write_round_summary(
            self.experiment_id, round_idx, val_mse_override, len(selected),
            wall_clock_ms, agg_outcome.comm_bytes, mean_energy, reward, agg_outcome.he_overhead_ms,
        )
        self.dt.commit()

        return RoundResult(
            round_idx=round_idx, val_mse=val_mse_override, reward=reward,
            n_participants=len(selected), mean_latency_ms=mean_latency,
            mean_energy_joules=mean_energy, comm_bytes=agg_outcome.comm_bytes,
            he_overhead_ms=agg_outcome.he_overhead_ms, wall_clock_ms=wall_clock_ms,
        )

    def run(self, n_rounds: int) -> List[RoundResult]:
        return [self.run_round(r) for r in range(n_rounds)]

    def test_metrics(self) -> dict:
        """Final test-set MSE/MAE/RMSE across all clients (Sec. 6.7)."""
        mses, maes = [], []
        for cid in self.client_ids:
            cd = self.clients[cid]
            model = self._local_models.get(cid, self.global_model)
            m = evaluate(model, cd.test_X, cd.test_y)
            if not np.isnan(m["mse"]):
                mses.append(m["mse"])
                maes.append(m["mae"])
        mse = float(np.mean(mses)) if mses else float("nan")
        mae = float(np.mean(maes)) if maes else float("nan")
        return {"test_mse": mse, "test_mae": mae, "test_rmse": mse ** 0.5 if mse == mse else float("nan")}

    def close(self) -> None:
        self.dt.close()
