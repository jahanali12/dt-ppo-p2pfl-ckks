"""Seven baseline configurations (B0-B6) and five fixed-strategy selection
heuristics used both as standalone baselines and as reference rollouts in the
PPO-vs-DQN comparison (Sec. 6.6, Sec. 5.3).

B0 Centralized           -- all clients' data pooled, single model, no FL/P2P/HE
B1 Local-only            -- each client trains+evaluates its own model, never aggregated
B2 FedAvg                -- centralized-coordinator averaging, random 35% participation, no HE
B3 P2PFL                 -- round-robin aggregation, no HE
B4 P2PFL+HE              -- round-robin + CKKS, random selection (extends [1] directly)
B5 DT+P2PFL+HE heuristic -- resource-aware selection heuristic, no learned orchestrator
B6 Proposed              -- DT + PPO orchestrator + P2PFL + HE + trust-aware exclusion
                             + adaptive edge assignment
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional

import numpy as np


class Aggregation(str, Enum):
    NONE = "none"             # B0/B1: no cross-client aggregation
    FEDAVG = "fedavg"
    P2P_PLAIN = "p2p_plain"
    P2P_CKKS = "p2p_ckks"


class Selection(str, Enum):
    ALL = "all"                 # centralized/local-only: every client every round
    RANDOM = "random"
    ROUND_ROBIN = "round_robin"
    RESOURCE_AWARE = "resource_aware"
    TRUST_AWARE = "trust_aware"
    HETEROGENEITY_AWARE = "heterogeneity_aware"
    PPO_POLICY = "ppo_policy"
    DQN_META = "dqn_meta"


@dataclass
class BaselineConfig:
    name: str
    aggregation: Aggregation
    selection: Selection
    participation_fraction: float = 0.35
    use_digital_twin: bool = False
    use_trust_exclusion: bool = False
    adaptive_edge_assignment: bool = False
    is_federated: bool = True
    is_centralized_pool: bool = False


BASELINES: Dict[str, BaselineConfig] = {
    "B0_centralized": BaselineConfig(
        name="B0_centralized", aggregation=Aggregation.NONE, selection=Selection.ALL,
        participation_fraction=1.0, is_federated=False, is_centralized_pool=True,
    ),
    "B1_local_only": BaselineConfig(
        name="B1_local_only", aggregation=Aggregation.NONE, selection=Selection.ALL,
        participation_fraction=1.0, is_federated=False,
    ),
    "B2_fedavg": BaselineConfig(
        name="B2_fedavg", aggregation=Aggregation.FEDAVG, selection=Selection.RANDOM,
        participation_fraction=0.35,
    ),
    "B3_p2pfl": BaselineConfig(
        name="B3_p2pfl", aggregation=Aggregation.P2P_PLAIN, selection=Selection.RANDOM,
        participation_fraction=0.35,
    ),
    "B4_p2pfl_he": BaselineConfig(
        name="B4_p2pfl_he", aggregation=Aggregation.P2P_CKKS, selection=Selection.RANDOM,
        participation_fraction=0.35,
    ),
    "B5_dt_heuristic": BaselineConfig(
        name="B5_dt_heuristic", aggregation=Aggregation.P2P_CKKS,
        selection=Selection.RESOURCE_AWARE, participation_fraction=0.35,
        use_digital_twin=True,
    ),
    "B6_proposed": BaselineConfig(
        name="B6_proposed", aggregation=Aggregation.P2P_CKKS, selection=Selection.PPO_POLICY,
        participation_fraction=0.35, use_digital_twin=True, use_trust_exclusion=True,
        adaptive_edge_assignment=True,
    ),
}


def ablation_configs() -> Dict[str, BaselineConfig]:
    """Six-way ablation: remove, in turn, the DT, the orchestrator, HE, trust,
    and adaptive edge assignment, each from the full B6 configuration
    (Sec. 6.6)."""
    base = BASELINES["B6_proposed"]
    variants = {
        "full_proposed": base,
        "no_digital_twin": BaselineConfig(
            **{**base.__dict__, "name": "no_digital_twin", "use_digital_twin": False,
               "selection": Selection.RANDOM},
        ),
        "no_orchestrator": BaselineConfig(
            **{**base.__dict__, "name": "no_orchestrator", "selection": Selection.RANDOM},
        ),
        "no_he": BaselineConfig(
            **{**base.__dict__, "name": "no_he", "aggregation": Aggregation.P2P_PLAIN},
        ),
        "no_trust": BaselineConfig(
            **{**base.__dict__, "name": "no_trust", "use_trust_exclusion": False},
        ),
        "no_adaptive_edge": BaselineConfig(
            **{**base.__dict__, "name": "no_adaptive_edge", "adaptive_edge_assignment": False},
        ),
    }
    return variants


# --- Fixed-strategy selection heuristics (also the surrogate-env reference
# rollouts of Sec. 5.3) --------------------------------------------------

def select_random(client_ids: List[str], k: int, rng: np.random.Generator) -> List[str]:
    return list(rng.choice(client_ids, size=min(k, len(client_ids)), replace=False))


def select_round_robin(client_ids: List[str], k: int, round_idx: int) -> List[str]:
    n = len(client_ids)
    start = (round_idx * k) % n
    idx = [(start + i) % n for i in range(k)]
    return [client_ids[i] for i in idx]


def select_resource_aware(
    client_ids: List[str], k: int, edge_compute: Dict[str, float], edge_congestion: Dict[str, float]
) -> List[str]:
    """Prefer clients served by the least-congested, highest-throughput edge
    nodes (B5's resource-aware heuristic)."""
    scores = {
        cid: edge_compute.get(cid, 0.0) * (1.0 - edge_congestion.get(cid, 0.0))
        for cid in client_ids
    }
    ranked = sorted(client_ids, key=lambda c: scores[c], reverse=True)
    return ranked[:k]


def select_trust_aware(client_ids: List[str], k: int, trust: Dict[str, float]) -> List[str]:
    ranked = sorted(client_ids, key=lambda c: trust.get(c, 0.5), reverse=True)
    return ranked[:k]


def select_heterogeneity_aware(
    client_ids: List[str], k: int, js_divergence: Dict[str, float]
) -> List[str]:
    """Prefer clients whose local profile diverges most from the population
    average, on the premise that diverse local updates carry more
    information (a non-IID-aware heuristic)."""
    ranked = sorted(client_ids, key=lambda c: js_divergence.get(c, 0.0), reverse=True)
    return ranked[:k]


def select_top_k_from_scores(client_ids: List[str], k: int, scores: np.ndarray) -> List[str]:
    """Used by both the PPO orchestrator and the DQN meta-selector (via its
    chosen heuristic's scores): top-k(scores) (Algorithm 1, line 3)."""
    order = np.argsort(-scores)[:k]
    return [client_ids[i] for i in order]
