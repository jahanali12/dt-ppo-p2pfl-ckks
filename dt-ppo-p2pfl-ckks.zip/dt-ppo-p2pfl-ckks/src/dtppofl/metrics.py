"""Metrics, paired significance testing, and results logging (Sec. 6.7).

The main seven-baseline comparison is repeated over three seeds and compared
with a paired (seed-blocked) t-test together with Cohen's d as a descriptive
effect size, reporting exact p-values rather than significance stars.
"""
from __future__ import annotations

import csv
import os
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List

import numpy as np
from scipy import stats


@dataclass
class RunRecord:
    experiment_id: str
    batch: str              # "main" | "ablation" | "scalability" | "robustness"
    config_name: str
    seed: int
    n_clients: int
    n_rounds: int
    test_mse: float
    test_mae: float
    test_rmse: float
    mean_latency_ms: float
    mean_energy_joules: float
    mean_comm_bytes: float
    he_overhead_ms: float
    wall_clock_s: float
    extra: Dict[str, Any] = field(default_factory=dict)


def append_run(record: RunRecord, csv_path: str) -> None:
    os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)
    row = asdict(record)
    extra = row.pop("extra")
    row.update(extra)
    file_exists = os.path.isfile(csv_path)
    with open(csv_path, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


def paired_ttest_and_cohens_d(baseline_mse: List[float], reference_mse: List[float]) -> dict:
    """Paired, seed-blocked t-test and Cohen's d for paired samples:
    d = mean(seed-wise differences) / std(seed-wise differences) (Sec. 6.7)."""
    a = np.asarray(baseline_mse, dtype=np.float64)
    b = np.asarray(reference_mse, dtype=np.float64)
    assert len(a) == len(b), "paired test requires equal-length, seed-matched arrays"
    diffs = a - b
    t_stat, p_value = stats.ttest_rel(a, b)
    d = float(diffs.mean() / diffs.std(ddof=1)) if diffs.std(ddof=1) > 0 else float("nan")
    return {"t_stat": float(t_stat), "p_value": float(p_value), "cohens_d": d, "mean_diff": float(diffs.mean())}


def mean_std(values: List[float]) -> Dict[str, float]:
    arr = np.asarray(values, dtype=np.float64)
    return {"mean": float(np.nanmean(arr)), "std": float(np.nanstd(arr, ddof=1)) if len(arr) > 1 else 0.0}
