"""PPO/DQN orchestrator training on the surrogate environment, and frozen-
policy inference used inside the real FL loop (Sec. 4.2, Sec. 5).

Training: 20,000 timesteps, deterministic-policy evaluation every 1,000
timesteps against a held-out evaluation seed stream, alongside five
fixed-strategy reference rollouts (Sec. 5.3). The trained policy is then
frozen and deployed inside fl_experiment.py for every reported main-loop
result; the surrogate is never used to report final accuracy/communication/
energy numbers (Sec. 5.1).
"""
from __future__ import annotations

import numpy as np

from .config import ExperimentConfig
from .orchestrator_env import SurrogateMetaSelectorEnv, SurrogateOrchestratorEnv, HEURISTIC_NAMES


def _lazy_imports():
    from stable_baselines3 import DQN, PPO
    return PPO, DQN


def train_ppo(cfg: ExperimentConfig, n_clients: int, mu, sigma, js_div, seed: int = 0):
    PPO, _ = _lazy_imports()
    env = SurrogateOrchestratorEnv(cfg, n_clients, mu, sigma, js_div, seed=seed)
    model = PPO(
        "MlpPolicy", env,
        learning_rate=cfg.orchestrator.ppo_learning_rate,
        n_steps=cfg.orchestrator.ppo_n_steps,
        batch_size=cfg.orchestrator.ppo_batch_size,
        gamma=cfg.orchestrator.ppo_gamma,
        gae_lambda=cfg.orchestrator.ppo_gae_lambda,
        clip_range=cfg.orchestrator.ppo_clip_range,
        verbose=0,
        seed=seed,
    )
    model.learn(total_timesteps=cfg.orchestrator.total_timesteps)
    return model


def train_dqn(cfg: ExperimentConfig, n_clients: int, mu, sigma, js_div, seed: int = 0):
    """DQN meta-selector over the five fixed heuristics (Sec. 5.3): "DQN's
    action space is a discrete choice among the five fixed heuristics rather
    than a genuinely novel per-client policy, so it converges within roughly
    2000-3000 timesteps to a reward level close to the best fixed heuristic"."""
    _, DQN = _lazy_imports()
    env = SurrogateMetaSelectorEnv(cfg, n_clients, mu, sigma, js_div, seed=seed)
    model = DQN(
        "MlpPolicy", env,
        learning_rate=cfg.orchestrator.dqn_learning_rate,
        buffer_size=cfg.orchestrator.dqn_buffer_size,
        gamma=cfg.orchestrator.dqn_gamma,
        verbose=0,
        seed=seed,
    )
    model.learn(total_timesteps=cfg.orchestrator.total_timesteps)
    return model


def evaluate_deterministic(
    model, cfg: ExperimentConfig, n_clients: int, mu, sigma, js_div, eval_seed: int, discrete: bool = False
) -> float:
    """One deterministic rollout of `surrogate_rounds_per_episode` rounds
    against a fixed evaluation seed, returning total episode reward -- the
    quantity plotted in Fig. 12 (Sec. 5.3)."""
    env_cls = SurrogateMetaSelectorEnv if discrete else SurrogateOrchestratorEnv
    env = env_cls(cfg, n_clients, mu, sigma, js_div, seed=eval_seed)
    obs, _ = env.reset(seed=eval_seed)
    total_reward = 0.0
    done = False
    while not done:
        action, _ = model.predict(obs, deterministic=True)
        obs, reward, terminated, truncated, _ = env.step(action)
        total_reward += reward
        done = terminated or truncated
    return total_reward


def evaluate_fixed_heuristic(
    cfg: ExperimentConfig, n_clients: int, mu, sigma, js_div, heuristic_name: str, eval_seed: int
) -> float:
    """Fixed-strategy reference rollout (random/round_robin/resource_aware/
    trust_aware/heterogeneity_aware), evaluated on the same seeds as PPO/DQN
    for Fig. 12's comparison (Sec. 5.3)."""
    idx = HEURISTIC_NAMES.index(heuristic_name)
    env = SurrogateMetaSelectorEnv(cfg, n_clients, mu, sigma, js_div, seed=eval_seed)
    obs, _ = env.reset(seed=eval_seed)
    total_reward = 0.0
    done = False
    while not done:
        obs, reward, terminated, truncated, _ = env.step(idx)
        total_reward += reward
        done = terminated or truncated
    return total_reward


def frozen_policy_scores(model, obs: np.ndarray) -> np.ndarray:
    """Run a frozen, previously trained PPO policy on one round's z-scored
    N x 11 feature matrix (flattened), returning the N-dimensional score
    vector used by top-k selection (Algorithm 1, line 3; Sec. 4.2)."""
    action, _ = model.predict(obs.ravel(), deterministic=True)
    return np.asarray(action).ravel()
