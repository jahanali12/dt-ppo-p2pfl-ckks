"""Low Carbon London (LCL) ingestion and preprocessing pipeline (Sec. 6.1-6.3).

Reproduces, step for step, the pipeline described in the paper and shown in
the "dataset acquisition-to-client preprocessing pipeline" figure:

  raw partition CSVs
    -> merge, dedup, drop NaN/negative
    -> restrict to common analysis window
    -> coverage filter (>= threshold of expected half-hourly slots)
    -> chronological 70/15/15 train/val/test split per client
    -> sliding windows (lookback, horizon) per client

Expected raw CSV schema (matching the official LCL partition files):
  LCLid, stdorToU, DateTime, KWH/hh (per half hour)
Column names are normalized on load; see `_COLUMN_ALIASES`.
"""
from __future__ import annotations

import glob
import os
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

_COLUMN_ALIASES = {
    "lclid": "household_id",
    "household_id": "household_id",
    "stdortou": "tariff",
    "tariff": "tariff",
    "datetime": "timestamp",
    "timestamp": "timestamp",
    "kwh/hh": "consumption_kwh",
    "kwh_hh": "consumption_kwh",
    "consumption_kwh": "consumption_kwh",
}

EXPECTED_SLOT_MINUTES = 30


@dataclass
class PipelineStats:
    raw_files_used: int
    raw_rows: int
    unique_households_raw: int
    duplicate_rows_removed: int
    missing_rows_removed: int
    negative_rows_found: int
    households_meeting_coverage: int
    households_candidate: int
    final_std: int
    final_tou: int
    final_rows: int


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    rename = {}
    for c in df.columns:
        key = c.strip().lower().replace(" ", "")
        if key in _COLUMN_ALIASES:
            rename[c] = _COLUMN_ALIASES[key]
    return df.rename(columns=rename)


def load_raw_partitions(raw_dir: str) -> pd.DataFrame:
    """Load and concatenate every CSV in raw_dir (the "22 of 168 official
    partition files" of Sec. 6.1)."""
    paths = sorted(glob.glob(os.path.join(raw_dir, "*.csv")))
    if not paths:
        raise FileNotFoundError(f"No CSV files found under {raw_dir}")
    frames = []
    for p in paths:
        df = pd.read_csv(p)
        df = _normalize_columns(df)
        frames.append(df)
    raw = pd.concat(frames, ignore_index=True)
    raw["timestamp"] = pd.to_datetime(raw["timestamp"], errors="coerce")
    raw["consumption_kwh"] = pd.to_numeric(raw["consumption_kwh"], errors="coerce")
    return raw, len(paths)


def clean(raw: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    """Dedup, drop NaN/negative rows (Sec. 6.2)."""
    n0 = len(raw)
    deduped = raw.drop_duplicates(subset=["household_id", "timestamp"])
    n_dup = n0 - len(deduped)

    missing_mask = deduped["consumption_kwh"].isna() | deduped["timestamp"].isna()
    n_missing = int(missing_mask.sum())
    cleaned = deduped.loc[~missing_mask].copy()

    neg_mask = cleaned["consumption_kwh"] < 0
    n_neg = int(neg_mask.sum())
    cleaned = cleaned.loc[~neg_mask].copy()

    return cleaned, {
        "duplicate_rows_removed": n_dup,
        "missing_rows_removed": n_missing,
        "negative_rows_found": n_neg,
    }


def filter_by_coverage(
    df: pd.DataFrame,
    window_start: str,
    window_end: str,
    coverage_threshold: float = 0.90,
    slot_minutes: int = EXPECTED_SLOT_MINUTES,
) -> Tuple[pd.DataFrame, dict]:
    """Restrict to the common analysis window and keep only households whose
    fraction of the expected half-hourly slots in that window is present
    (Sec. 6.2)."""
    start = pd.Timestamp(window_start)
    end = pd.Timestamp(window_end)
    windowed = df[(df["timestamp"] >= start) & (df["timestamp"] <= end)].copy()

    expected_slots = int((end - start) / pd.Timedelta(minutes=slot_minutes)) + 1
    counts = windowed.groupby("household_id")["timestamp"].nunique()
    coverage = counts / expected_slots

    candidates = coverage.index
    keep_ids = coverage[coverage >= coverage_threshold].index
    kept = windowed[windowed["household_id"].isin(keep_ids)].copy()

    stats = {
        "households_candidate": int(len(candidates)),
        "households_meeting_coverage": int(len(keep_ids)),
        "coverage_mean": float(coverage.mean()) if len(coverage) else float("nan"),
        "coverage_median": float(coverage.median()) if len(coverage) else float("nan"),
    }
    return kept, stats


def chronological_split(
    df: pd.DataFrame, train_frac: float = 0.70, val_frac: float = 0.15
) -> Dict[str, pd.DataFrame]:
    """Split each household's own time span at identical fractional
    cut-points -- chronological, not random, to avoid future-data leakage
    (Sec. 6.3)."""
    train_parts, val_parts, test_parts = [], [], []
    for hid, g in df.sort_values("timestamp").groupby("household_id"):
        n = len(g)
        n_train = int(n * train_frac)
        n_val = int(n * val_frac)
        train_parts.append(g.iloc[:n_train])
        val_parts.append(g.iloc[n_train:n_train + n_val])
        test_parts.append(g.iloc[n_train + n_val:])
    return {
        "train": pd.concat(train_parts, ignore_index=True) if train_parts else df.iloc[0:0],
        "val": pd.concat(val_parts, ignore_index=True) if val_parts else df.iloc[0:0],
        "test": pd.concat(test_parts, ignore_index=True) if test_parts else df.iloc[0:0],
    }


def jensen_shannon_divergence(p: np.ndarray, q: np.ndarray, eps: float = 1e-12) -> float:
    """JS divergence between two discrete distributions (base-2 log, in
    [0, 1]), used for each household's normalized 48-slot daily profile
    against the population-average profile (Sec. 6.3)."""
    p = p / (p.sum() + eps)
    q = q / (q.sum() + eps)
    m = 0.5 * (p + q)

    def kl(a, b):
        mask = a > 0
        return float(np.sum(a[mask] * np.log2(a[mask] / (b[mask] + eps) + eps)))

    return 0.5 * kl(p, m) + 0.5 * kl(q, m)


def household_daily_profile(g: pd.DataFrame, slot_minutes: int = EXPECTED_SLOT_MINUTES) -> np.ndarray:
    """Mean consumption per half-hourly slot-of-day, normalized to sum to 1."""
    slots_per_day = (24 * 60) // slot_minutes
    slot_of_day = ((g["timestamp"].dt.hour * 60 + g["timestamp"].dt.minute) // slot_minutes).values
    profile = np.zeros(slots_per_day)
    counts = np.zeros(slots_per_day)
    for s, v in zip(slot_of_day, g["consumption_kwh"].values):
        profile[s] += v
        counts[s] += 1
    counts[counts == 0] = 1
    profile = profile / counts
    total = profile.sum()
    return profile / total if total > 0 else profile


def heterogeneity_stats(df: pd.DataFrame) -> dict:
    """Non-IID severity measures (Sec. 6.3): coefficient of variation of mean
    household consumption, JS divergence of each household's daily profile
    from the population-average profile, and winter/summer consumption
    ratio."""
    per_household_mean = df.groupby("household_id")["consumption_kwh"].mean()
    cv = float(per_household_mean.std() / per_household_mean.mean()) if per_household_mean.mean() else float("nan")

    profiles = {}
    for hid, g in df.groupby("household_id"):
        profiles[hid] = household_daily_profile(g)
    pop_profile = np.mean(list(profiles.values()), axis=0) if profiles else np.array([])

    js_divs = {hid: jensen_shannon_divergence(p, pop_profile) for hid, p in profiles.items()}
    js_values = np.array(list(js_divs.values())) if js_divs else np.array([np.nan])

    winter_months = {12, 1, 2}
    summer_months = {6, 7, 8}
    ratios = []
    for hid, g in df.groupby("household_id"):
        w = g.loc[g["timestamp"].dt.month.isin(winter_months), "consumption_kwh"].mean()
        s = g.loc[g["timestamp"].dt.month.isin(summer_months), "consumption_kwh"].mean()
        if s and s > 0 and not np.isnan(w) and not np.isnan(s):
            ratios.append(w / s)
    ratios = np.array(ratios) if ratios else np.array([np.nan])

    return {
        "cv_mean_consumption": cv,
        "js_divergence_per_household": js_divs,
        "js_divergence_mean": float(np.nanmean(js_values)),
        "js_divergence_max": float(np.nanmax(js_values)) if len(js_values) else float("nan"),
        "winter_summer_ratio_mean": float(np.nanmean(ratios)),
        "winter_summer_ratio_std": float(np.nanstd(ratios)),
    }


def build_client_dataset(
    raw_dir: str,
    window_start: str,
    window_end: str,
    coverage_threshold: float = 0.90,
) -> Tuple[Dict[str, pd.DataFrame], PipelineStats, dict]:
    """End-to-end pipeline entry point: raw partitions -> clean -> coverage
    filter -> returns per-household cleaned dataframes plus the pipeline and
    heterogeneity statistics tables reported in Sec. 7.1 (Tables 4-5)."""
    raw, n_files = load_raw_partitions(raw_dir)
    n_raw = len(raw)
    n_unique_raw = raw["household_id"].nunique()
    std_raw = int((raw["tariff"].astype(str).str.lower().str.startswith("std")).sum())

    cleaned, clean_stats = clean(raw)
    kept, coverage_stats = filter_by_coverage(
        cleaned, window_start, window_end, coverage_threshold
    )

    tariff_lower = kept["tariff"].astype(str).str.lower()
    n_std = int(kept.loc[tariff_lower.str.startswith("std"), "household_id"].nunique())
    n_tou = int(kept["household_id"].nunique() - n_std)

    stats = PipelineStats(
        raw_files_used=n_files,
        raw_rows=n_raw,
        unique_households_raw=n_unique_raw,
        duplicate_rows_removed=clean_stats["duplicate_rows_removed"],
        missing_rows_removed=clean_stats["missing_rows_removed"],
        negative_rows_found=clean_stats["negative_rows_found"],
        households_meeting_coverage=coverage_stats["households_meeting_coverage"],
        households_candidate=coverage_stats["households_candidate"],
        final_std=n_std,
        final_tou=n_tou,
        final_rows=len(kept),
    )

    het = heterogeneity_stats(kept)

    per_household = {hid: g.sort_values("timestamp") for hid, g in kept.groupby("household_id")}
    return per_household, stats, het
