"""Two aggregation topologies (Sec. 3.3):

  - fedavg: centralized-coordinator average (Eq. 1)
  - round_robin_ckks: peer-to-peer round-robin scheme extending [1], in which
    possibly-encrypted parameter vectors are relayed and summed across the
    selected peers before division by their count at the initiating peer
    (Eq. 2, Sec. 4.3)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np

from . import encryption
from .config import CKKSConfig


@dataclass
class AggregationOutcome:
    new_params: np.ndarray
    comm_bytes: int
    he_overhead_ms: float


def fedavg(client_params: Dict[str, np.ndarray]) -> AggregationOutcome:
    """Eq. 1: theta_{r+1} = (1/|S_r|) sum_i theta_i, centralized, plaintext."""
    stacked = np.stack(list(client_params.values()), axis=0)
    avg = stacked.mean(axis=0)
    n_params = stacked.shape[1]
    comm_bytes = len(client_params) * encryption.plaintext_payload_bytes(n_params) * 2  # up+down
    return AggregationOutcome(new_params=avg, comm_bytes=comm_bytes, he_overhead_ms=0.0)


def round_robin_plain(client_params: Dict[str, np.ndarray]) -> AggregationOutcome:
    """Plain (unencrypted) P2PFL round-robin relay: structurally the same
    accumulate-then-divide as Eq. 2 but without CKKS (B3 baseline)."""
    stacked = np.stack(list(client_params.values()), axis=0)
    total = stacked.sum(axis=0)
    avg = total / len(client_params)
    n_params = stacked.shape[1]
    comm_bytes = len(client_params) * encryption.plaintext_payload_bytes(n_params)
    return AggregationOutcome(new_params=avg, comm_bytes=comm_bytes, he_overhead_ms=0.0)


def round_robin_ckks(
    client_params: Dict[str, np.ndarray],
    ckks_cfg: CKKSConfig,
    context=None,
) -> AggregationOutcome:
    """Eq. 2 / Sec. 4.3: each selected client encrypts its parameter vector
    under the shared CKKS context; ciphertexts are relayed and homomorphically
    summed round-robin across peers; the initiating peer decrypts the sum and
    divides by the participant count."""
    if context is None:
        context = encryption.make_context(ckks_cfg)

    ciphertexts = []
    total_encrypt_ms = 0.0
    comm_bytes = 0
    for params in client_params.values():
        res = encryption.encrypt_vector(context, params, ckks_cfg)
        ciphertexts.append(res.ciphertext)
        total_encrypt_ms += res.encrypt_ms
        comm_bytes += res.payload_bytes

    agg = encryption.sum_and_decrypt(ciphertexts, context, divide_by=len(client_params))
    he_overhead_ms = total_encrypt_ms + agg.aggregate_ms
    return AggregationOutcome(
        new_params=agg.plaintext_vector, comm_bytes=comm_bytes, he_overhead_ms=he_overhead_ms
    )
