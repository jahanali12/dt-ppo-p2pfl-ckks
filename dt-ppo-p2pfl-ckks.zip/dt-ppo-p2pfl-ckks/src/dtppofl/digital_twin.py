"""Digital Twin state store (Sec. 4.1): an operational SQLite database, not a
diagram. Two tables, exactly as described in the paper:

  client_state  -- the 11-dimensional per-client, per-round state vector
                   x_{i,r} of Eq. 3 (Table 2 lists every field's provenance).
  round_summary -- per-round global validation loss, participant count,
                   wall-clock time, communication bytes, energy, and reward.

The orchestrator queries client_state before each round's decision and
nothing else in the pipeline reads or writes it (Sec. 4.1).
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterable, Optional

import numpy as np

from .config import DigitalTwinConfig

STATE_FIELDS = [
    "mu", "sigma", "js_div",              # real (Sec. 6.3)
    "uplink_mbps", "latency_ms", "packet_loss",  # simulated network
    "edge_compute_gflops", "edge_congestion",     # simulated edge
    "prev_loss", "staleness", "trust",            # measured
]
assert len(STATE_FIELDS) == 11, "Eq. 3 defines an 11-dimensional state vector"


@dataclass
class ClientStateRow:
    experiment_id: str
    round_idx: int
    client_id: str
    mu: float
    sigma: float
    js_div: float
    uplink_mbps: float
    latency_ms: float
    packet_loss: float
    edge_compute_gflops: float
    edge_congestion: float
    prev_loss: float
    staleness: int
    trust: float

    def as_vector(self) -> np.ndarray:
        return np.array([getattr(self, f) for f in STATE_FIELDS], dtype=np.float64)


class DigitalTwin:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._conn = sqlite3.connect(db_path)
        self._init_schema()

    def _init_schema(self) -> None:
        cols = ", ".join(f"{f} REAL" for f in STATE_FIELDS)
        self._conn.execute(
            f"""
            CREATE TABLE IF NOT EXISTS client_state (
                experiment_id TEXT NOT NULL,
                round_idx INTEGER NOT NULL,
                client_id TEXT NOT NULL,
                {cols},
                PRIMARY KEY (experiment_id, round_idx, client_id)
            )
            """
        )
        self._conn.execute(
            """
            CREATE TABLE IF NOT EXISTS round_summary (
                experiment_id TEXT NOT NULL,
                round_idx INTEGER NOT NULL,
                global_val_mse REAL,
                n_participants INTEGER,
                wall_clock_ms REAL,
                comm_bytes INTEGER,
                energy_joules REAL,
                reward REAL,
                he_encrypt_agg_ms REAL,
                PRIMARY KEY (experiment_id, round_idx)
            )
            """
        )
        self._conn.commit()

    def write_client_state(self, row: ClientStateRow) -> None:
        placeholders = ", ".join(["?"] * (3 + len(STATE_FIELDS)))
        values = [row.experiment_id, row.round_idx, row.client_id] + [
            getattr(row, f) for f in STATE_FIELDS
        ]
        self._conn.execute(
            f"INSERT OR REPLACE INTO client_state VALUES ({placeholders})", values
        )

    def write_round_summary(
        self,
        experiment_id: str,
        round_idx: int,
        global_val_mse: float,
        n_participants: int,
        wall_clock_ms: float,
        comm_bytes: int,
        energy_joules: float,
        reward: float,
        he_encrypt_agg_ms: float = 0.0,
    ) -> None:
        self._conn.execute(
            """
            INSERT OR REPLACE INTO round_summary VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                experiment_id, round_idx, global_val_mse, n_participants,
                wall_clock_ms, comm_bytes, energy_joules, reward, he_encrypt_agg_ms,
            ),
        )

    def commit(self) -> None:
        self._conn.commit()

    def latest_client_state(
        self, experiment_id: str, client_ids: Iterable[str]
    ) -> dict:
        """Most recent state row per client (prior round's values), used to
        build the feature matrix the orchestrator reads before selecting
        this round's participants (Algorithm 1, line 2)."""
        out = {}
        for cid in client_ids:
            cur = self._conn.execute(
                """
                SELECT * FROM client_state
                WHERE experiment_id = ? AND client_id = ?
                ORDER BY round_idx DESC LIMIT 1
                """,
                (experiment_id, cid),
            )
            r = cur.fetchone()
            out[cid] = r
        return out

    def feature_matrix(
        self, experiment_id: str, client_ids: Iterable[str]
    ) -> np.ndarray:
        """N x 11 raw feature matrix, one row per client, most recent state
        available (or zeros/defaults for a client never yet observed)."""
        latest = self.latest_client_state(experiment_id, client_ids)
        cols = {f: i for i, f in enumerate(STATE_FIELDS)}
        mat = np.zeros((len(latest), len(STATE_FIELDS)), dtype=np.float64)
        for row_idx, (cid, r) in enumerate(latest.items()):
            if r is None:
                continue
            for f in STATE_FIELDS:
                mat[row_idx, cols[f]] = r[3 + cols[f]]  # skip experiment_id, round_idx, client_id
        return mat

    def close(self) -> None:
        self._conn.commit()
        self._conn.close()


def zscore_normalize(matrix: np.ndarray) -> np.ndarray:
    """Per-round z-scoring of the N x 11 feature matrix, matching the
    normalization used during orchestrator policy training (Sec. 4.2)."""
    mean = matrix.mean(axis=0, keepdims=True)
    std = matrix.std(axis=0, keepdims=True)
    std[std < 1e-8] = 1.0
    return (matrix - mean) / std
