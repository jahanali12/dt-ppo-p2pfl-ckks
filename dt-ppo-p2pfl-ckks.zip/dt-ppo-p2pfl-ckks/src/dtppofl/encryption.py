"""CKKS homomorphic encryption wrapper (Sec. 3.4, Eq. 2).

Polynomial modulus degree 8192, coefficient-modulus chain [40, 21, 21, 40]
bits, via TenSEAL (Microsoft SEAL bindings) -- exactly the parameters stated
in the paper. If TenSEAL is not importable (e.g. it failed to build on the
reviewer's platform), this module falls back to a *cost-simulated* stand-in
that reproduces the same timing/payload-size model without doing real
cryptography. The fallback is loud about what it is -- it must never be used
to report real HE-overhead numbers.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from .config import CKKSConfig

try:
    import tenseal as ts

    _HAS_TENSEAL = True
except Exception:  # pragma: no cover - exercised only when tenseal is absent
    _HAS_TENSEAL = False


@dataclass
class EncryptResult:
    ciphertext: object
    encrypt_ms: float
    payload_bytes: int


@dataclass
class AggregateResult:
    plaintext_vector: np.ndarray
    aggregate_ms: float


def make_context(cfg: CKKSConfig):
    if not _HAS_TENSEAL:
        return None
    context = ts.context(
        ts.SCHEME_TYPE.CKKS,
        poly_modulus_degree=cfg.poly_modulus_degree,
        coeff_mod_bit_sizes=list(cfg.coeff_mod_bit_sizes),
    )
    context.generate_galois_keys()
    context.global_scale = 2 ** cfg.global_scale_pow2
    return context


def encrypt_vector(context, vector: np.ndarray, cfg: CKKSConfig) -> EncryptResult:
    vector = np.asarray(vector, dtype=np.float64)
    t0 = time.perf_counter()
    if _HAS_TENSEAL and context is not None:
        ct = ts.ckks_vector(context, vector.tolist())
        payload_bytes = len(ct.serialize())
    else:
        ct = _FallbackCiphertext(vector.copy())
        payload_bytes = _simulated_ciphertext_bytes(len(vector), cfg)
    encrypt_ms = (time.perf_counter() - t0) * 1000.0
    return EncryptResult(ciphertext=ct, encrypt_ms=encrypt_ms, payload_bytes=payload_bytes)


def sum_and_decrypt(
    ciphertexts: Sequence, secret_context, divide_by: int
) -> AggregateResult:
    """Homomorphically sum the given ciphertexts and decrypt+average (Eq. 2)."""
    t0 = time.perf_counter()
    if _HAS_TENSEAL and ciphertexts and isinstance(ciphertexts[0], ts.CKKSVector):
        acc = ciphertexts[0]
        for ct in ciphertexts[1:]:
            acc = acc + ct
        plain = np.array(acc.decrypt()) / max(divide_by, 1)
    else:
        acc = np.sum([ct.vector for ct in ciphertexts], axis=0)
        plain = acc / max(divide_by, 1)
    aggregate_ms = (time.perf_counter() - t0) * 1000.0
    return AggregateResult(plaintext_vector=plain, aggregate_ms=aggregate_ms)


class _FallbackCiphertext:
    """Cost-simulated stand-in used only when TenSEAL is unavailable."""

    def __init__(self, vector: np.ndarray):
        self.vector = vector


def _simulated_ciphertext_bytes(n_params: int, cfg: CKKSConfig) -> int:
    """Rough CKKS ciphertext size model, used only by the fallback path.

    A CKKS ciphertext packs up to poly_modulus_degree/2 real values per
    ciphertext; each ciphertext is two ring elements of size
    poly_modulus_degree * (sum of coeff-modulus bit sizes) / 8 bytes. This is
    an order-of-magnitude stand-in, not a substitute for measuring real
    TenSEAL serialization.
    """
    slots = cfg.poly_modulus_degree // 2
    n_ciphertexts = max(1, -(-n_params // slots))  # ceil division
    bits = sum(cfg.coeff_mod_bit_sizes)
    bytes_per_ciphertext = 2 * cfg.poly_modulus_degree * bits / 8.0
    return int(n_ciphertexts * bytes_per_ciphertext)


def plaintext_payload_bytes(n_params: int) -> int:
    """float32 plaintext parameter vector size, for the plaintext-vs-encrypted
    payload comparison (Fig. 10b in the paper)."""
    return n_params * 4


def using_real_tenseal() -> bool:
    return _HAS_TENSEAL
