"""Simulated 6G communication layer and MEC edge model (Sec. 3.2, Table 3).

Nothing here is measured: the dataset carries no network telemetry, so every
quantity is drawn from an explicit, literature-informed range and the paper
states this plainly (Sec. 6.5). This module is the single place those draws
happen, so a reviewer can see exactly what "simulated" means in this codebase.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .config import NetworkSimConfig


@dataclass
class ClientNetworkState:
    uplink_mbps: float
    latency_ms: float
    packet_loss: float


@dataclass
class EdgeState:
    compute_gflops: float
    congestion: float


def sample_client_network_state(
    rng: np.random.Generator, cfg: NetworkSimConfig, unreliable: bool = False
) -> ClientNetworkState:
    """Draw one client's (uplink, latency, packet-loss) triple for one round."""
    uplink = rng.uniform(*cfg.uplink_mbps_range)
    latency = rng.uniform(*cfg.one_way_latency_ms_range)
    loss = rng.uniform(*cfg.packet_loss_prob_range)
    if unreliable:
        latency *= rng.uniform(*cfg.unreliable_latency_multiplier)
        loss = min(0.5, loss * rng.uniform(*cfg.unreliable_packet_loss_multiplier))
    return ClientNetworkState(uplink_mbps=uplink, latency_ms=latency, packet_loss=loss)


def sample_edge_state(rng: np.random.Generator, cfg: NetworkSimConfig) -> EdgeState:
    return EdgeState(
        compute_gflops=rng.uniform(*cfg.edge_compute_gflops_range),
        congestion=rng.uniform(*cfg.edge_congestion_range),
    )


def transmission_time_ms(
    payload_bytes: int, net: ClientNetworkState, cfg: NetworkSimConfig
) -> float:
    """Transmission time: payload / uplink, inflated by a retransmission factor
    that grows with packet loss, plus the round's one-way latency (Sec. 3.2).
    """
    uplink_bytes_per_ms = (net.uplink_mbps * 1e6 / 8.0) / 1000.0
    base_ms = payload_bytes / max(uplink_bytes_per_ms, 1e-9)
    retransmission_factor = 1.0 + cfg.retransmission_growth * net.packet_loss
    return base_ms * retransmission_factor + net.latency_ms


def device_energy_joules(
    payload_bytes: int, rng: np.random.Generator, cfg: NetworkSimConfig
) -> float:
    """Per-byte device energy coefficient drawn from Table 3's range (Sec. 3.2)."""
    nj_per_byte = rng.uniform(*cfg.device_energy_nj_per_byte_range)
    return payload_bytes * nj_per_byte * 1e-9


def edge_compute_time_ms(
    task_gflops: float, edge: EdgeState
) -> float:
    """Edge compute time: task size over the edge's congestion-discounted
    effective throughput (Sec. 3.2)."""
    effective_gflops = edge.compute_gflops * (1.0 - edge.congestion)
    return (task_gflops / max(effective_gflops, 1e-6)) * 1000.0


def maybe_corrupt_update(
    rng: np.random.Generator, cfg: NetworkSimConfig, unreliable: bool
) -> str:
    """For a client simulated as unreliable, decide whether this round's local
    update is corrupted (label-noised), dropped out entirely, or submitted
    normally (Sec. 5.2).
    """
    if not unreliable:
        return "normal"
    if rng.uniform() < cfg.corrupt_or_dropout_prob_if_unreliable:
        return rng.choice(["corrupt", "dropout"])
    return "normal"
