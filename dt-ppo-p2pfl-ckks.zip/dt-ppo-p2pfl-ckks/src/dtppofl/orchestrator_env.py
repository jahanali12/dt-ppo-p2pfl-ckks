"""Fast surrogate Gymnasium environment for orchestrator policy training
(Sec. 5.1).

Training the orchestrator inside the real FL loop is computationally
intractable for the thousands of timesteps DRL training requires. This
surrogate environment is built from the same real per-client heterogeneity
statistics (mu_i, sigma_i, D_i^JS) and the same simulated 6G/MEC/reliability
generators used in the real pipeline, with a proxy accuracy-quality term
(inverse Jensen-Shannon divergence of selected clients, plus a staleness
bonus) standing in for the real, expensive validation-loss improvement. The
trained policy is frozen and deployed inside the real fl_experiment loop; the
surrogate is used only for policy search, never for reporting final
accuracy/communication/energy numbers.
"""
from __future__ import annotations

from typing import Optional

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from . import network_sim
from .config import ExperimentConfig
from .digital_twin import STATE_FIELDS, zscore_normalize
from .reward import RoundQuantities, compute_reward


class SurrogateOrchestratorEnv(gym.Env):
    """One episode = `surrogate_rounds_per_episode` rounds over a fixed
    client population. Action: continuous per-client score vector in
    [-1, 1]^N (top-k(scores) selects participants, matching Algorithm 1 line
    3's real deployment). Observation: the N x 11 z-scored DT feature matrix,
    flattened."""

    metadata = {"render_modes": []}

    def __init__(
        self,
        cfg: ExperimentConfig,
        n_clients: int,
        mu: np.ndarray,
        sigma: np.ndarray,
        js_div: np.ndarray,
        seed: Optional[int] = None,
    ):
        super().__init__()
        self.cfg = cfg
        self.n_clients = n_clients
        self.mu = mu
        self.sigma = sigma
        self.js_div = js_div
        self.rng = np.random.default_rng(seed)

        self.k = max(1, round(cfg.orchestrator.participation_fraction * n_clients))
        self.rounds_per_episode = cfg.orchestrator.surrogate_rounds_per_episode
        self.unreliable_fraction = cfg.orchestrator.surrogate_unreliable_fraction

        self.observation_space = spaces.Box(
            low=-10.0, high=10.0, shape=(n_clients * len(STATE_FIELDS),), dtype=np.float32
        )
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(n_clients,), dtype=np.float32)

        self._round = 0
        self._staleness = np.zeros(n_clients)
        self._trust = np.full(n_clients, cfg.digital_twin.trust_init)
        self._unreliable = self.rng.uniform(size=n_clients) < self.unreliable_fraction

    def _build_state_matrix(self) -> np.ndarray:
        n = self.n_clients
        mat = np.zeros((n, len(STATE_FIELDS)))
        for i in range(n):
            net = network_sim.sample_client_network_state(
                self.rng, self.cfg.network, unreliable=bool(self._unreliable[i])
            )
            edge = network_sim.sample_edge_state(self.rng, self.cfg.network)
            mat[i] = [
                self.mu[i], self.sigma[i], self.js_div[i],
                net.uplink_mbps, net.latency_ms, net.packet_loss,
                edge.compute_gflops, edge.congestion,
                0.0,  # prev_loss placeholder (surrogate does not run real training)
                self._staleness[i], self._trust[i],
            ]
        self._last_raw_matrix = mat
        return mat

    def reset(self, *, seed: Optional[int] = None, options: Optional[dict] = None):
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self._round = 0
        self._staleness = np.zeros(self.n_clients)
        self._trust = np.full(self.n_clients, self.cfg.digital_twin.trust_init)
        mat = self._build_state_matrix()
        obs = zscore_normalize(mat).astype(np.float32).ravel()
        return obs, {}

    def step(self, action: np.ndarray):
        action = np.asarray(action).ravel()
        order = np.argsort(-action)[: self.k]
        selected = np.zeros(self.n_clients, dtype=bool)
        selected[order] = True

        # Proxy accuracy-quality term: inverse JS divergence of selected
        # clients (lower divergence => more representative => better proxy
        # quality), plus a staleness bonus rewarding clients not recently
        # selected (Sec. 5.1).
        proxy_quality = 1.0 / (1.0 + self.js_div[selected].mean()) if selected.any() else 0.0
        staleness_bonus = float(self._staleness[selected].mean()) if selected.any() else 0.0
        proxy_mse = max(0.0, 1.0 - proxy_quality) + 0.01 * self.rng.normal()

        mat = self._last_raw_matrix
        mean_latency = float(mat[selected, 4].mean()) if selected.any() else 0.0
        mean_energy = float(selected.sum() * 0.05)  # lightweight stand-in, surrogate only
        mean_comm = float(selected.sum() * 5000.0)
        he_overhead = float(selected.sum() * 2.0)
        mean_trust = float(self._trust[selected].mean()) if selected.any() else 0.0

        q = RoundQuantities(
            mse=proxy_mse,
            mean_latency_ms=mean_latency,
            mean_energy_joules=mean_energy,
            mean_comm_bytes=mean_comm,
            he_overhead_ms=he_overhead,
            mean_trust=mean_trust,
        )
        reward = compute_reward(q, self.cfg.reward) + 0.2 * staleness_bonus

        self._staleness += 1
        self._staleness[selected] = 0
        self._trust[selected] = np.clip(
            self._trust[selected] + 0.05 * (1 - self._unreliable[selected].astype(float) * 2),
            0.0, 1.0,
        )

        self._round += 1
        terminated = self._round >= self.rounds_per_episode
        mat = self._build_state_matrix()
        obs = zscore_normalize(mat).astype(np.float32).ravel()
        return obs, float(reward), terminated, False, {"selected": selected}


HEURISTIC_NAMES = [
    "random", "round_robin", "resource_aware", "trust_aware", "heterogeneity_aware",
]


class SurrogateMetaSelectorEnv(SurrogateOrchestratorEnv):
    """DQN variant (Sec. 5.3): the action space is a *discrete* choice among
    the five fixed-strategy heuristics rather than a continuous per-client
    score. "DQN's action space is a discrete choice among the five fixed
    heuristics rather than a genuinely novel per-client policy" -- this class
    makes that constraint explicit and literal, matching the paper's
    empirical PPO-vs-DQN comparison exactly: DQN can only ever match the best
    of the five heuristics, never exceed it, by construction.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.action_space = spaces.Discrete(len(HEURISTIC_NAMES))

    def _heuristic_scores(self, heuristic_idx: int) -> np.ndarray:
        name = HEURISTIC_NAMES[heuristic_idx]
        mat = self._last_raw_matrix
        if name == "random":
            return self.rng.uniform(size=self.n_clients)
        if name == "round_robin":
            start = (self._round * self.k) % self.n_clients
            scores = np.zeros(self.n_clients)
            for i in range(self.k):
                scores[(start + i) % self.n_clients] = self.n_clients - i
            return scores
        if name == "resource_aware":
            return mat[:, 6] * (1.0 - mat[:, 7])  # edge_compute_gflops * (1 - congestion)
        if name == "trust_aware":
            return self._trust.copy()
        if name == "heterogeneity_aware":
            return self.js_div.copy()
        raise ValueError(name)

    def step(self, action):
        heuristic_idx = int(action)
        scores = self._heuristic_scores(heuristic_idx)
        # Convert the heuristic's ranking into the same [-1, 1]-scored action
        # vector the parent class's step() expects, so selection logic is
        # shared between PPO and DQN exactly as in the real orchestrator.
        rank = scores.argsort().argsort()  # 0 = lowest score
        pseudo_action = (rank / max(self.n_clients - 1, 1)) * 2.0 - 1.0
        return super().step(pseudo_action)
