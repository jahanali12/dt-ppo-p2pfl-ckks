"""Trust-score mechanism (Sec. 5.2, Eq. 5).

CKKS aggregation only reveals the round's summed ciphertext to the initiating
peer, so per-client raw parameter deviation cannot be inspected without
breaking the framework's own privacy property. Trust is instead computed from
metadata each client can honestly report without exposing its update: an
exponential moving average of how closely a client's self-reported local
training loss tracks the round's median.
"""
from __future__ import annotations

from typing import Dict

from .config import TrustConfig


def update_trust(
    prev_trust: float,
    client_loss: float,
    round_median_loss: float,
    cfg: TrustConfig,
) -> float:
    """Eq. 5:
    rho_{i,r} = 0.8 * rho_{i,r-1} + 0.2 * 1 / (1 + |L_{i,r} - median_j L_{j,r}| / median_j L_{j,r})
    """
    denom = max(round_median_loss, 1e-8)
    deviation_term = 1.0 / (1.0 + abs(client_loss - round_median_loss) / denom)
    return cfg.ema_alpha_prior * prev_trust + cfg.ema_alpha_new * deviation_term


def update_trust_batch(
    prev_trust: Dict[str, float],
    client_losses: Dict[str, float],
    cfg: TrustConfig,
) -> Dict[str, float]:
    """Vectorized convenience wrapper over update_trust for one round's
    selected clients, using the round's median reported loss."""
    import numpy as np

    if not client_losses:
        return {}
    median_loss = float(np.median(list(client_losses.values())))
    return {
        cid: update_trust(prev_trust.get(cid, cfg.ema_alpha_prior), loss, median_loss, cfg)
        for cid, loss in client_losses.items()
    }


def trust_exclusion_mask(
    trust_scores: Dict[str, float], cfg: TrustConfig
) -> Dict[str, bool]:
    """Algorithm 1, line 4: exclude i in S_r with trust rho_{i,r} < threshold.
    Returns True = keep, False = excluded."""
    return {cid: (score >= cfg.exclusion_threshold) for cid, score in trust_scores.items()}
