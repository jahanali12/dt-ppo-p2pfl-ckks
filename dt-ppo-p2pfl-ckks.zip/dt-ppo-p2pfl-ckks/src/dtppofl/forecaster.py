"""Load forecaster: a deliberately small one-layer GRU (Sec. 6.4).

Hidden size 24 (the paper states "1969 trainable parameters" at this size for
a single input feature -- see the docstring on `count_params` below for the
arithmetic), predicting the next half-hourly reading from a 48-step (24h)
lookback window, trained with Adam (lr 1e-3) and MSE loss. Per-client windows
are z-score normalized using statistics computed on that client's own
training split only.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np
import torch
from torch import nn

from .config import ForecasterConfig


class GRUForecaster(nn.Module):
    """1 input feature -> GRU(hidden_size) -> Linear(hidden_size, horizon).

    Parameter count for hidden_size=24, input_size=1, 1 layer, horizon=1:
      GRU:   3 * (hidden*(input+hidden) + 2*hidden) = 3*(24*25 + 48) = 1944
      Linear: hidden*horizon + horizon = 24 + 1 = 25
      Total: 1969  -- matches the paper's stated parameter count.
    """

    def __init__(self, cfg: ForecasterConfig):
        super().__init__()
        self.cfg = cfg
        self.gru = nn.GRU(input_size=1, hidden_size=cfg.hidden_size, num_layers=cfg.num_layers,
                           batch_first=True)
        self.head = nn.Linear(cfg.hidden_size, cfg.horizon)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, lookback, 1)
        out, h_n = self.gru(x)
        last_hidden = h_n[-1]  # (batch, hidden_size)
        return self.head(last_hidden)  # (batch, horizon)


def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


@dataclass
class ClientNormalization:
    mean: float
    std: float

    def transform(self, x: np.ndarray) -> np.ndarray:
        return (x - self.mean) / (self.std if self.std > 1e-8 else 1.0)

    def inverse(self, x: np.ndarray) -> np.ndarray:
        return x * (self.std if self.std > 1e-8 else 1.0) + self.mean


def fit_normalization(train_series: np.ndarray) -> ClientNormalization:
    return ClientNormalization(mean=float(train_series.mean()), std=float(train_series.std()))


def make_windows(
    series: np.ndarray, lookback: int, horizon: int
) -> Tuple[np.ndarray, np.ndarray]:
    """Sliding windows (lookback, horizon) over a per-client chronological
    series -- Sec. 6.3's "sliding windows (lookback=48, horizon=1) per client"
    and Fig. 'preprocessing pipeline' final step."""
    n = len(series)
    n_windows = n - lookback - horizon + 1
    if n_windows <= 0:
        return np.empty((0, lookback)), np.empty((0, horizon))
    X = np.stack([series[i:i + lookback] for i in range(n_windows)])
    y = np.stack([series[i + lookback:i + lookback + horizon] for i in range(n_windows)])
    return X, y


def train_one_client(
    model: GRUForecaster,
    X_train: np.ndarray,
    y_train: np.ndarray,
    cfg: ForecasterConfig,
    epochs: int = 1,
    device: str = "cpu",
    max_windows: int | None = None,
) -> float:
    """One local-training pass (Algorithm 1, LocalTrain). Returns mean
    training MSE loss for this client this round -- the L_{i,r} fed into the
    trust mechanism (Eq. 5)."""
    if max_windows is None:
        max_windows = cfg.max_train_windows_per_client_per_round
    if len(X_train) > max_windows:
        idx = np.random.choice(len(X_train), size=max_windows, replace=False)
        X_train, y_train = X_train[idx], y_train[idx]
    if len(X_train) == 0:
        return float("nan")

    model.to(device)
    model.train()
    opt = torch.optim.Adam(model.parameters(), lr=cfg.learning_rate)
    loss_fn = nn.MSELoss()

    Xt = torch.tensor(X_train, dtype=torch.float32, device=device).unsqueeze(-1)
    yt = torch.tensor(y_train, dtype=torch.float32, device=device)

    last_loss = float("nan")
    for _ in range(epochs):
        opt.zero_grad()
        pred = model(Xt)
        loss = loss_fn(pred, yt)
        loss.backward()
        opt.step()
        last_loss = float(loss.item())
    return last_loss


@torch.no_grad()
def evaluate(
    model: GRUForecaster, X: np.ndarray, y: np.ndarray, device: str = "cpu"
) -> dict:
    """Test/val MSE, MAE, RMSE in normalized units (Sec. 6.7)."""
    if len(X) == 0:
        return {"mse": float("nan"), "mae": float("nan"), "rmse": float("nan")}
    model.to(device)
    model.eval()
    Xt = torch.tensor(X, dtype=torch.float32, device=device).unsqueeze(-1)
    yt = torch.tensor(y, dtype=torch.float32, device=device)
    pred = model(Xt)
    err = pred - yt
    mse = float((err ** 2).mean().item())
    mae = float(err.abs().mean().item())
    return {"mse": mse, "mae": mae, "rmse": mse ** 0.5}


def get_flat_params(model: nn.Module) -> np.ndarray:
    return np.concatenate([p.detach().cpu().numpy().ravel() for p in model.parameters()])


def set_flat_params(model: nn.Module, flat: np.ndarray) -> None:
    offset = 0
    for p in model.parameters():
        n = p.numel()
        p.data.copy_(
            torch.tensor(flat[offset:offset + n], dtype=p.dtype).view(p.shape)
        )
        offset += n


def average_params(param_vectors: list[np.ndarray]) -> np.ndarray:
    """FedAvg (Eq. 1): theta_{r+1} = (1/|S_r|) * sum_i theta_i."""
    return np.mean(np.stack(param_vectors, axis=0), axis=0)
