"""Central configuration dataclasses.

Default values are the literature-informed, explicitly-not-calibrated ranges
and hyperparameters stated in the manuscript (Sec. 3.2, 3.5, 6.4-6.6, Table 2-3).
Every field below is traceable to a specific sentence or table in the paper;
see the inline comments.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Tuple


@dataclass
class NetworkSimConfig:
    """Simulated 6G/MEC parameter ranges (Sec. 3.2, Table 3).

    These are explicit experimental assumptions "informed by the general
    order of magnitude reported in 5G-Advanced, early-6G, and MEC literature,
    not values calibrated against any specific standard or measurement"
    (Sec. 6.5). Units: Mbps, ms, fraction, GFLOP/s, fraction, nJ/byte.
    """

    uplink_mbps_range: Tuple[float, float] = (20.0, 500.0)
    one_way_latency_ms_range: Tuple[float, float] = (1.0, 20.0)
    packet_loss_prob_range: Tuple[float, float] = (0.0001, 0.02)
    edge_compute_gflops_range: Tuple[float, float] = (50.0, 400.0)
    edge_congestion_range: Tuple[float, float] = (0.0, 0.8)
    device_energy_nj_per_byte_range: Tuple[float, float] = (0.5, 5.0)
    retransmission_growth: float = 8.0  # inflates transmission time with packet loss

    # Unreliable-client simulation (Sec. 5.2, 6.6; robustness study Sec. 6.6)
    unreliable_latency_multiplier: Tuple[float, float] = (1.5, 3.0)
    unreliable_packet_loss_multiplier: Tuple[float, float] = (3.0, 8.0)
    label_noise_std_if_corrupted: float = 1.5
    corrupt_or_dropout_prob_if_unreliable: float = 0.5


@dataclass
class CKKSConfig:
    """CKKS homomorphic encryption parameters (Sec. 3.4, Eq. 2)."""

    poly_modulus_degree: int = 8192
    coeff_mod_bit_sizes: Tuple[int, int, int, int] = (40, 21, 21, 40)
    global_scale_pow2: int = 21  # 2**21, sits between the two 21-bit mid primes


@dataclass
class ForecasterConfig:
    """GRU load forecaster (Sec. 6.4)."""

    lookback: int = 48          # 24h of half-hourly readings
    horizon: int = 1            # next half-hourly reading
    hidden_size: int = 24       # "deliberately small", 1969 trainable params at this size
    num_layers: int = 1
    learning_rate: float = 1e-3
    optimizer: str = "adam"
    loss: str = "mse"
    max_train_windows_per_client_per_round: int = 600  # Sec. 7, compute-budget cap


@dataclass
class DigitalTwinConfig:
    """Digital Twin state vector x_{i,r} (Eq. 3) and DB paths (Sec. 4.1)."""

    state_dim: int = 11
    db_path: str = "results/digital_twin.sqlite"
    trust_init: float = 0.5


@dataclass
class TrustConfig:
    """Trust-score EMA (Sec. 5.2, Eq. 5)."""

    ema_alpha_prior: float = 0.8   # weight on rho_{i, r-1}
    ema_alpha_new: float = 0.2     # weight on the new deviation term
    exclusion_threshold: float = 0.3  # Algorithm 1, line 4: exclude if rho < threshold


@dataclass
class RewardConfig:
    """Multi-objective per-round reward (Sec. 3.5, Eq. 4).

    Default weights (w1..w6) = (1.0, 0.15, 0.10, 0.10, 0.05, 0.20), stated
    explicitly in the paper as a design judgment, not fitted. Normalization
    constants (100, 10, 1e6, 100) are the fixed scales from Eq. 4.
    """

    w_accuracy: float = 1.0
    w_latency: float = 0.15
    w_energy: float = 0.10
    w_comm: float = 0.10
    w_he_overhead: float = 0.05
    w_trust: float = 0.20

    latency_norm: float = 100.0
    energy_norm: float = 10.0
    comm_norm: float = 1.0e6
    he_overhead_norm: float = 100.0


@dataclass
class OrchestratorConfig:
    """PPO/DQN orchestrator and its surrogate training environment (Sec. 5, 4.2)."""

    participation_fraction: float = 0.35  # k = round(0.35 * N), Sec. 4.2
    surrogate_rounds_per_episode: int = 12
    surrogate_unreliable_fraction: float = 0.10
    total_timesteps: int = 20_000
    eval_every_timesteps: int = 1_000
    ppo_learning_rate: float = 3e-4
    ppo_n_steps: int = 256
    ppo_batch_size: int = 64
    ppo_gamma: float = 0.99
    ppo_gae_lambda: float = 0.95
    ppo_clip_range: float = 0.2
    dqn_learning_rate: float = 1e-3
    dqn_buffer_size: int = 20_000
    dqn_gamma: float = 0.99


@dataclass
class FLExperimentConfig:
    """Federated round / experiment-matrix settings (Sec. 6.6-6.7, Sec. 7)."""

    n_rounds: int = 12
    main_comparison_seeds: Tuple[int, ...] = (0, 1, 2)
    ablation_scalability_robustness_seeds: Tuple[int, ...] = (0, 1)
    scalability_client_counts: Tuple[int, ...] = (30, 75, 151)
    robustness_unreliable_fractions: Tuple[float, ...] = (0.0, 0.10, 0.20, 0.30)
    coverage_threshold: float = 0.90


@dataclass
class ExperimentConfig:
    """Top-level config bundling all sub-configs; loaded from configs/*.yaml."""

    network: NetworkSimConfig = field(default_factory=NetworkSimConfig)
    ckks: CKKSConfig = field(default_factory=CKKSConfig)
    forecaster: ForecasterConfig = field(default_factory=ForecasterConfig)
    digital_twin: DigitalTwinConfig = field(default_factory=DigitalTwinConfig)
    trust: TrustConfig = field(default_factory=TrustConfig)
    reward: RewardConfig = field(default_factory=RewardConfig)
    orchestrator: OrchestratorConfig = field(default_factory=OrchestratorConfig)
    fl: FLExperimentConfig = field(default_factory=FLExperimentConfig)
    results_csv: str = "results/all_runs.csv"


def load_config(path: str | None = None) -> ExperimentConfig:
    """Load an ExperimentConfig, overlaying a YAML file's values onto the defaults."""
    cfg = ExperimentConfig()
    if path is None:
        return cfg
    import yaml

    with open(path, "r") as f:
        raw = yaml.safe_load(f) or {}

    def _apply(section_obj, section_dict):
        for k, v in (section_dict or {}).items():
            if hasattr(section_obj, k):
                current = getattr(section_obj, k)
                if isinstance(v, list) and isinstance(current, tuple):
                    v = tuple(v)
                setattr(section_obj, k, v)

    for section_name in (
        "network", "ckks", "forecaster", "digital_twin", "trust",
        "reward", "orchestrator", "fl",
    ):
        if section_name in raw:
            _apply(getattr(cfg, section_name), raw[section_name])
    if "results_csv" in raw:
        cfg.results_csv = raw["results_csv"]
    return cfg
