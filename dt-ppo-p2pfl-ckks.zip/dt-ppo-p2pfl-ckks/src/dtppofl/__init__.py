"""dtppofl: Digital Twin + PPO-orchestrated, CKKS-encrypted peer-to-peer federated learning.

Clean-room reference implementation of the methodology described in
"Digital Twin-Assisted AI-Native 6G Edge Intelligence for Privacy-Preserving
Federated Learning in Smart Grids" (submitted to MDPI Electronics). See the
top-level README.md for what this package does and does not claim to reproduce.
"""

__version__ = "0.1.0"
