# Suggested "Code and Data Availability" statement

Paste/adapt this into the manuscript's Code and Data Availability section, replacing the bracketed
placeholders once the repository is actually pushed to GitHub (and, ideally, archived with Zenodo
for a permanent DOI before final submission):

> The code implementing the Digital Twin state store, simulated 6G/MEC network model, CKKS
> homomorphic encryption pipeline, PPO/DQN orchestrator and its surrogate training environment,
> and the full seven-baseline, six-way-ablation, three-scale, four-level-robustness experiment
> matrix described in Sections 3–7 is available at
> `https://github.com/<your-username>/<your-repo-name>` under the MIT license. The Low Carbon
> London smart-meter dataset used in this study is third-party data released by UK Power Networks
> under a CC-BY 4.0 license and is available from the London Datastore
> (https://data.london.gov.uk/dataset/smartmeter-energy-use-data-in-london-households); it is not
> redistributed in the code repository. The 22 partition files used in this study, and the derived
> per-client processed dataset, are available from the corresponding author on reasonable request.

## Honesty note for the authors

This repository was built in this session as a methodology-faithful, runnable reimplementation of
what the paper describes — it was not recovered from the original experiment code that produced
the numbers in Tables 6–11 of the manuscript. Before citing a specific commit/release in the
submitted paper, you (the authors) should:

1. Push this repository to your own GitHub account/organization.
2. Decide whether to also upload the real, original experiment code and logs (`results/all_runs.csv`,
   per-round history, the trained PPO/DQN checkpoints) if you still have them, so the repository's
   `results/` actually matches the paper's tables. If you do, replace the synthetic-data demo
   framing in `README.md` accordingly.
3. If you cannot recover the original run, keep this README's disclosure intact (or write your own
   equivalent) rather than imply the repository reproduces the exact published numbers — MDPI and
   your co-authors/reviewers should not be told a clean-room reimplementation is the original
   artifact.
4. Consider archiving a release on Zenodo (free, integrates with GitHub) to get a permanent DOI for
   the "Code and Data Availability" citation, which MDPI prefers over a bare GitHub URL.
